package com.example.kotlinclientpc4

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import okhttp3.RequestBody.Companion.asRequestBody
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

class MainActivity : AppCompatActivity() {

    private val client = OkHttpClient()
    private val workers = mapOf(
        "Python Worker" to "http://44.223.6.36:8080",
        "JavaScript Worker" to "http://44.223.6.36:8081",
        "Java Worker" to "http://44.223.6.36:8082"
    )

    private lateinit var selectedFileUri: Uri
    private lateinit var selectedFileName: String
    private lateinit var spinnerWorker: Spinner
    private lateinit var listViewFiles: ListView
    private lateinit var etFileName: EditText
    private lateinit var etDownloadPath: EditText
    private lateinit var downloadPath: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnUpload = findViewById<Button>(R.id.btnUpload)
        val btnSelectFile = findViewById<Button>(R.id.btnSelectFile)
        val btnListFiles = findViewById<Button>(R.id.btnListFiles)
        val btnDownloadFile = findViewById<Button>(R.id.btnDownloadFile)
        etFileName = findViewById(R.id.etFileName)
        etDownloadPath = findViewById(R.id.etDownloadPath)
        spinnerWorker = findViewById(R.id.spinnerWorker)
        listViewFiles = findViewById(R.id.listViewFiles)

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, workers.keys.toList())
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerWorker.adapter = adapter

        btnSelectFile.setOnClickListener {
            openFilePicker()
        }

        btnUpload.setOnClickListener {
            val workerUrl = workers[spinnerWorker.selectedItem.toString()] ?: return@setOnClickListener
            if (::selectedFileUri.isInitialized) {
                uploadFile(workerUrl, selectedFileUri)
            } else {
                Toast.makeText(this, "Please select a file first", Toast.LENGTH_SHORT).show()
            }
        }

        btnListFiles.setOnClickListener {
            val workerUrl = workers[spinnerWorker.selectedItem.toString()] ?: return@setOnClickListener
            listFiles(workerUrl)
        }

        btnDownloadFile.setOnClickListener {
            val workerUrl = workers[spinnerWorker.selectedItem.toString()] ?: return@setOnClickListener
            val fileName = etFileName.text.toString()
            if (fileName.isEmpty()) {
                Toast.makeText(this, "Please enter a file name", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val downloadPath = etDownloadPath.text.toString()
            downloadFile(workerUrl, fileName, downloadPath)
        }
    }

    private fun openFilePicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(intent, 1)
    }

    private fun getFileName(uri: Uri): String {
        var result: String? = null
        if (uri.scheme == "content") {
            val cursor = contentResolver.query(uri, null, null, null, null)
            cursor?.use {
                if (it.moveToFirst()) {
                    val columnIndex = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (columnIndex >= 0) {
                        result = it.getString(columnIndex)
                    }
                }
            }
        }
        if (result == null) {
            result = uri.path
            val cut = result?.lastIndexOf('/')
            if (cut != -1) {
                result = result?.substring(cut!! + 1)
            }
        }
        return result ?: "unknown_file"
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == Activity.RESULT_OK) {
            data?.data?.let { uri ->
                selectedFileUri = uri
                selectedFileName = getFileName(uri)
                findViewById<TextView>(R.id.tvSelectedFile).text = selectedFileName
            }
        }
    }

    private fun uploadFile(workerUrl: String, fileUri: Uri) {
        val file = File(cacheDir, selectedFileName)
        contentResolver.openInputStream(fileUri)?.use { inputStream ->
            FileOutputStream(file).use { outputStream ->
                inputStream.copyTo(outputStream)
            }
        }

        val requestBody = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("file", file.name, file.asRequestBody())
            .build()

        val request = Request.Builder()
            .url("$workerUrl/upload")
            .post(requestBody)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Upload failed: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                runOnUiThread {
                    if (response.isSuccessful) {
                        Toast.makeText(this@MainActivity, "File uploaded successfully", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this@MainActivity, "Upload failed: ${response.message}", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        })
    }

    private fun listFiles(workerUrl: String) {
        val request = Request.Builder()
            .url("$workerUrl/list")
            .get()
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Failed to list files: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                runOnUiThread {
                    if (response.isSuccessful) {
                        val jsonResponse = response.body?.string()
                        val jsonObject = JSONObject(jsonResponse)
                        val files = jsonObject.getJSONArray("files")
                        val fileList = mutableListOf<String>()
                        for (i in 0 until files.length()) {
                            fileList.add(files.getString(i))
                        }
                        val adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_list_item_1, fileList)
                        listViewFiles.adapter = adapter
                    } else {
                        Toast.makeText(this@MainActivity, "Failed to list files: ${response.message}", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        })
    }

    private fun downloadFile(workerUrl: String, fileName: String, downloadPath: String) {
        val request = Request.Builder()
            .url("$workerUrl/download?file_name=$fileName")
            .get()
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Download failed: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                if (response.isSuccessful) {
                    val file = File(downloadPath, fileName)
                    response.body?.byteStream()?.use { inputStream ->
                        FileOutputStream(file).use { outputStream ->
                            inputStream.copyTo(outputStream)
                        }
                    }
                    runOnUiThread {
                        Toast.makeText(this@MainActivity, "File downloaded to ${file.path}", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    runOnUiThread {
                        Toast.makeText(this@MainActivity, "Download failed: ${response.message}", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        })
    }
}
